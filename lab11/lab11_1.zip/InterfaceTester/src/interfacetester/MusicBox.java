/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfacetester;

import java.util.ArrayList;

/**
 *
 * @author Kantarat
 */
public class MusicBox implements SimpleQueue{
    
    private ArrayList <String> music = new ArrayList<>();
     
    public MusicBox (){
        
    }
    @Override
    public void enqueue(Object o){
        music.add((String) o);
        System.out.println(o+" is added in queue");
    }
    @Override
    public void dequeue(){
        System.out.println("Now playing "+music.get(0));
        music.remove(0);
    }
}
