/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10_2;

/**
 *
 * @author Kantarat
 */
public interface Electric {
    
    public static final double LOW_VOLTAGE = 480;
    double HIGH_VOLTAGE = 600;
    public abstract double getVoltage();
    
}
