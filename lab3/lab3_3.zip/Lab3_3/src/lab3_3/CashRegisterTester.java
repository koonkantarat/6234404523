/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_3;

/**
 *
 * @author Kantarat
 */
public class CashRegisterTester {
    public static void main(String[] args) {
        CashRegister changeTest = new CashRegister(7);
        changeTest.recordPurchase(50);
        changeTest.recordPurchase(10);
        changeTest.enterPayment(100);
        changeTest.recordTaxablePurchase(20);
        System.out.println("Your change is "+changeTest.giveChange());
    }
    }
