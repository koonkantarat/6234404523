/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_3;

/**
 *
 * @author usci
 */
public class TimeInterval {
    //private int start;
    //private int end;
    private double minStart;
    private double minEnd;
    public TimeInterval(int start,int end){
        //this.start=start;
        //this.end=end;
        minStart = (start%100)+Math.floor((start/100)*60);
        minEnd = (end%100)+Math.floor((end/100)*60);
    }
    public int getHours(){
        double hours = Math.floor(minEnd-minStart)/60;
        return (int)hours;
    }
    public int getMinutes(){
        double min = (minEnd-minStart)%60;
        return (int)min;
    }
    

}
