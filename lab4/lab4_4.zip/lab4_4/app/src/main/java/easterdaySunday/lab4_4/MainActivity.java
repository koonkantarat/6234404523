package easterdaySunday.lab4_4;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.icu.text.Edits;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import static easterdaySunday.lab4_4.R.id.easter;


public class MainActivity extends AppCompatActivity {
    static String theYear, easterDay;
    EditText easter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setContentView(R.layout.activity_main);
        Button check = findViewById(R.id.enter);
        easter = this.<EditText> findViewById(R.id.easter);
        check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                theYear = easter.getText().toString();

                if(theYear.length()!=0) {
                    int num = Integer.parseInt(theYear);

                    easterdaySunday easter = new easterdaySunday(num);
                    easterDay =  easter.examine();
                    startActivity(new Intent(MainActivity.this, easterdaySundaytester.class));
                }

            }
        });


    }

}
