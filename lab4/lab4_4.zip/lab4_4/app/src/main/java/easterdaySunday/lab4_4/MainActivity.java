package easterdaySunday.lab4_4;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    static String theYear, easterDay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button check = findViewById(R.id.enter);
        final EditText easter =  findViewById (R.id.easter);
        check.setOnClickListener(new View.OnClickListener() {
            class activity {
            }

            @Override
            public void onClick(View v) {

                theYear = easter.getText().toString();

                if(theYear.length()!=0) {
                    int num = Integer.parseInt(theYear);

                    easterdaySunday easter = new easterdaySunday(num);
                    easterDay =  easter.examine();
                    startActivity(new Intent(MainActivity.this, MainResult.class));
                }

            }
        });


    }

}
