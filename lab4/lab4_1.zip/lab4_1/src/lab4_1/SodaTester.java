/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_1;

import java.util.Scanner;

/**
 *
 * @author usci
 */
public class SodaTester {
    public static void main(String[] args) {
        Scanner test= new Scanner(System.in);
        System.out.print("Enter height: ");
        float height = test.nextFloat();
        System.out.print("Enter diameter: ");
        float diameter = test.nextFloat();
        SodaCan tester = new SodaCan(height,diameter);
        System.out.printf("Volume: %.2f%n",(float)tester.getVolume());
        System.out.printf("Surface area: %.2f%n",(float)tester.getSurfaceArea());
        
    }
}
