/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GregorianCalendar;

import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 *
 * @author usci
 */
public class Lab2_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GregorianCalendar cal = new GregorianCalendar(2020,Calendar.JANUARY,9);
        cal.add(Calendar.DAY_OF_MONTH,10);
        int weekday = cal.get(Calendar.DAY_OF_WEEK);
        int dayOfMonth = cal.get(Calendar.DAY_OF_MONTH);
        int month = cal.get(Calendar.MONTH);
        int year = cal.get(Calendar.YEAR);
        System.out.println(weekday);
        System.out.println(dayOfMonth);
        System.out.println(month);
        System.out.println(year);
       
        
    }
    
}
