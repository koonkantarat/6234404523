/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question;

import java.lang.reflect.Array;

/**
 *
 * @author Kantarat
 */
public class Question {

    /**
     * @param args the command line arguments
     */
    private String text;
    private String answer;
    //private Array question;
    //private int i =0 ; 
    
    public Question(){
        
    }
    public Question(String text){
        this.text = text;
    }
    
    public void setText (String text){
        this.text = text;
        //i=0;
        //for (i < text.length){
    }
    public String getText (){
        return text;
    }
    public void setAnswer (String answer){
        this.answer = answer;
    }
    public String getAnswer(){
        return answer;
    }
    public boolean checkAnswer (String response){
        String check = response;
        if (check.equals(answer)){
            return true;
        }
        return false;
    }
    public void display(){
        System.out.println(getText());
    }
}
