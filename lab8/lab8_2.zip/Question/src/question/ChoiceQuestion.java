/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question;

import java.util.ArrayList;

/**
 *
 * @author Kantarat
 */
public class ChoiceQuestion extends Question{
    ArrayList<String> choices = new ArrayList<String>();
    
    public ChoiceQuestion (String text){
        super(text);
    }
    
    public void addChoice (String choice, boolean correct){
        choices.add(choice);
        if (correct){
            setAnswer(choice);
        }
    }
    @Override
    public void display(){
        super.display();
        for(int i=0; i<choices.size();i++){
            int j = i+1;
            System.out.println(j+":"+choices.get(i));
        }
    }
    @Override
    public boolean checkAnswer(String response){
        boolean correct = choices.get(Integer.parseInt(response)-1).equals(super.getAnswer());
        return correct;
    }
}
