/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question;

/**
 *
 * @author Kantarat
 */
public class NumericQuestion extends Question{
    public NumericQuestion(String text){
        super(text);
    }
    
    @Override
    public boolean checkAnswer(String response){
        double result = Double.parseDouble(response) - Double.parseDouble(getAnswer());
        boolean correct = Math.abs(result) <= 0.01 ;
        return correct;
    }
}
