/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab8_1;

/**
 *
 * @author Kantarat
 */
public class Car {

    private double gas;
    private double efficiency;
    
    public Car (){
        
    }
    public Car (double gas,double efficiency){
        this.gas = gas;
        this.efficiency = efficiency;
    }
    
    public void drive(double distance) {
        double gasRe =  this.gas-(distance/this.efficiency);
        if (gasRe<0)
            System.out.println("“You cannot drive too far, please" +"add gas”");
        else
            this.gas = gasRe;
    }
    
    public void setGas(double amount) {
        this.gas = amount;
    }
    
    public double getGas(){
        return this.gas;
                
    }
    
    public double getEfficiency(){
        return this.efficiency;
    }
    
    public void addGas(double amount) {
        this.gas += amount;
    }
}
