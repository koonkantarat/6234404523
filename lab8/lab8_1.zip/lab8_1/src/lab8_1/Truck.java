/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab8_1;

/**
 *
 * @author Kantarat
 */
public class Truck extends Car{
    
    private int M_weight;
    private int weight;
    
    public Truck(double gas, double efficiency,int M_weight,int weight) {
        super(gas, efficiency);
        this.M_weight = M_weight;
        this.weight = weight;
        if (weight>=M_weight)
            this.weight = M_weight;
        else
            this.weight = M_weight;
    }
    
    @Override
    public void drive(double distance){
            double gasTruck = distance/getEfficiency();
            if (weight<1)
                gasTruck = gasTruck;
            else if (weight>=1 && weight <=10){
                gasTruck += gasTruck*0.1;
            }
            else if(weight>=11 && weight <=20){
                gasTruck += gasTruck*0.2;
            }
            else {
                gasTruck += gasTruck*0.3;
            }
            if (gasTruck>getGas())
                System.out.println("“You cannot drive too far, please" +"add gas”");
            else
                setGas(getGas()-gasTruck);
        }
     }

