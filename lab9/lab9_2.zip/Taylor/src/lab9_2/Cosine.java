/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab9_2;

/**
 *
 * @author Kantarat
 */
public class Cosine extends Taylor{

    private double approx=0;
    
    public Cosine(int k,double x){
        super(k,x);
    }
    
    @Override
    public double getApprox(){
        for (int n=0;n<=getlter();n++){
            approx = approx + ((Math.pow(getValue(), 2*n)*Math.pow(-1, n))/super.factorial(2*n));
        }
        return approx;     
    }
    @Override
    public void printValue(){
        System.out.println("Value from Math.cos() is "+Math.cos(getValue())+".");
        System.out.println("Approximated value is "+getApprox()+".");
        
    }
}

