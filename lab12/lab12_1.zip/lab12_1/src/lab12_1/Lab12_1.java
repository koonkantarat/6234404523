/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab12_1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 *
 * @author Kantarat
 */
public class Lab12_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException{
        int line = 0,numWord = 0,numChar = 0;
        String str ;
        File file = new File("sequential.txt");
        PrintWriter f = new PrintWriter(file);
        Scanner input = new Scanner(System.in);
        str = input.nextLine();
        
        while (!"quit".equals(str)){
            f.print(str+"\n");
            str = input.nextLine();
        }
        f.close();
        Scanner read = new Scanner(file);
        while (read.hasNextLine()){
            String lineRead = read.nextLine();
            line ++;
            String[] word = lineRead.split(" ");
            numWord += word.length;
            numChar += lineRead.length();
        }
        read.close();
        System.out.println("Total characters : "+numChar);
        System.out.println("Total words : "+numWord);
        System.out.println("Total lines : "+line);
         
    }
    
}
