/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab5_1;

/**
 *
 * @author Kantarat
 */
public class Zeller {
    private int dayOfMonth;
    private int month; 
    private int year;
    public Zeller(int year,int month,int dayOfMonth){
        switch(month){
            case 1 : this.month=13;this.year=year-1;break;
            case 2 : this.month=14;this.year=year-1;break;
            default:this.year=year;this.month=month;break;
        }
}   
    public enum Day{
        SUNDAY("Sunday"), MONDAY("Monday"),TUESDAY("Tuesday"), WEDNESDAY("Wednesday"), THURSDAY("Thursday"),FRIDAY("Friday"), SATURDAY("Saturday");
        private final String day;
        private Day(String day){
            this.day=day;
        }
        @Override
        public String toString(){
            return this.day;
        }
    }
    public Day getDayOfWeek(){
        int k = this.year%100;
        int j = this.year/100;
        if (this.month==1){
            this.month=13;
            this.year=this.year-1;
        }
        else if (this.month==2){
            this.month=14;this.year=this.year-1;
        }
        int dayOfWeek = (dayOfMonth+((26*(this.month+1))/10)+k+(k/4)+(j/4)+(5*j))%7;
        Day returnDay = null;
        switch(dayOfWeek){
            case 0 : returnDay=Day.SATURDAY;break;
            case 1 : returnDay=Day.SUNDAY;break;
            case 2 : returnDay=Day.MONDAY;break;
            case 3 : returnDay=Day.TUESDAY;break;
            case 4 : returnDay=Day.WEDNESDAY;break;
            case 5 : returnDay=Day.THURSDAY;break;
            case 7 : returnDay=Day.FRIDAY;break;
        }
        return returnDay;
    }      
}
    

